package com.example.model;

public class Contact {
    private int id;
    private String name;
    private String phone;
    private String email;
    public void setName(String parameter) {
		// TODO Auto-generated method stub
		this.name=parameter;
	}
    public void setPhone(String parameter) {
		// TODO Auto-generated method stub
		this.phone=parameter;
	}
    public void setEmail(String parameter) {
		// TODO Auto-generated method stub
		this.email=parameter;
	}
    public void setId(int parameter) {
		// TODO Auto-generated method stub
		this.id=parameter;
	}
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}
	public String getPhone() {
		// TODO Auto-generated method stub
		return phone;
	}
	public int getId() {
		// TODO Auto-generated method stub
		return id;
	}
    
	

    // Getters & Setters
}
